#include <iostream>
#include <string>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node(int val) : data(val), next(nullptr) {}
};

class Queue {
private:
    Node* head; 
    Node* tail; 

public:
    Queue() : head(nullptr), tail(nullptr) {}

       void enqueue(int x) {
        Node* newNode = new Node(x);
        if (tail == nullptr) { 
            head = tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }

    void dequeue() {
        if (head == nullptr) {
            cout << "Queue is empty" << endl;
            return;
        }
        Node* temp = head;
        head = head->next;
        if (head == nullptr) { 
            tail = nullptr;
        }
        delete temp;
    }

    void print() const {
        Node* current = head;
        while (current != nullptr) {
            cout << current->data << " ";
            current = current->next;
        }
        cout << endl;
    }

    ~Queue() {
        while (head != nullptr) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
    }
};

int main() {
    int n;
    cin >> n;
    Queue queue;

    for (int i = 0; i < n; ++i) {
        string operation;
        cin >> operation;
        if (operation == "enqueue") {
            int x;
            cin >> x;
            queue.enqueue(x);
        } else if (operation == "dequeue") {
            queue.dequeue();
        }
    }

    queue.print();
    return 0;
}