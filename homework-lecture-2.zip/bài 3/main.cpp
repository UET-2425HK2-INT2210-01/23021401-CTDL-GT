#include <iostream>
using namespace std;

struct Node {
    int value;
    Node* prev;
    Node* next;
    
    Node(int val) : value(val), prev(nullptr), next(nullptr) {}
};

Node* createDoublyLinkedList(int numbers[], int n) {
    if (n == 0) return nullptr;
    
    Node* head = new Node(numbers[0]);
    Node* current = head;
    
    for (int i = 1; i < n; ++i) {
        Node* newNode = new Node(numbers[i]);
        current->next = newNode;
        newNode->prev = current;
        current = newNode;
    }
    
    return head;
}

int countTriplets(Node* head) {
    if (!head || !head->next || !head->next->next) {
        return 0; 
    }
    
    int count = 0;
    Node* current = head->next; 
    
    while (current->next) { 
        Node* prevNode = current->prev;
        Node* nextNode = current->next;
        
        if (prevNode->value + current->value + nextNode->value == 0) {
            count++;
        }
        
        current = current->next;
    }
    
    return count;
}

void freeDoublyLinkedList(Node* head) {
    while (head) {
        Node* temp = head;
        head = head->next;
        delete temp;
    }
}

int main() {
    int n;
    cin >> n; 
    
    int numbers[n];
    for (int i = 0; i < n; ++i) {
        cin >> numbers[i]; 
    }
    
       Node* head = createDoublyLinkedList(numbers, n);
    
       int result = countTriplets(head);
  
    cout << result << endl;
    
      freeDoublyLinkedList(head);
    
    return 0;
}