#include <iostream>
#include <algorithm> 
using namespace std;

int main() {
    double numbers[5];

       cout << "Enter 5 real numbers separated by spaces: ";
    for (int i = 0; i < 5; ++i) {
        cin >> numbers[i];
    }

        double smallest = numbers[0];
    double greatest = numbers[0];

    for (int i = 1; i < 5; ++i) {
        if (numbers[i] < smallest) {
            smallest = numbers[i];
        }
        if (numbers[i] > greatest) {
            greatest = numbers[i];
        }
    }

        double sum = greatest + smallest;

        cout << "The sum of the greatest and smallest numbers is: " << sum << endl;

    return 0;
}