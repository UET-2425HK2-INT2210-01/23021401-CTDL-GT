#include <iostream>
#include <string>
#include <sstream>
#include <vector>

int main() {
  
    std::cout << "how are you : ";
    
 
    std::string sentence;
    std::getline(std::cin, sentence);
    
 
    std::istringstream stream(sentence);
    std::vector<std::string> words;
    std::string word;
    
    while (stream >> word) {
        words.push_back(word);
    }
    
    
    std::cout << "uoy era woh: ";
    for (int i = words.size() - 1; i >= 0; --i) {
        std::cout << words[i] << " ";
    }
    std::cout << std::endl;
    
    return 0;
}