#include <iostream>
using namespace std;

int gcd(int m, int n) {
    while (n != 0) {
        int remainder = m % n; 
        m = n; 
        n = remainder; 
    }
    return m; 
}

int main() {
    int m, n;

        cout << "Enter two positive integers: ";
    cin >> m >> n;

      int result = gcd(m, n);

     cout << "The greatest common divisor of " << m << " and " << n << " is: " << result << endl;

    return 0;
}