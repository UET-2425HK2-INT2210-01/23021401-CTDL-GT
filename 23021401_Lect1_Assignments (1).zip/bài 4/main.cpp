#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int n;

    // Read the number of elements in the list
    std::cout << "Enter the number of elements: ";
    std::cin >> n;

    // Check if n is valid
    if (n <= 0) {
        std::cout << "Invalid input. The number of elements must be positive." << std::endl;
        return 1; // Exit with an error code
    }

    // Read the list of numbers
    std::vector<int> numbers(n);
    std::cout << "Enter " << n << " integers separated by spaces: ";
    for (int i = 0; i < n; ++i) {
        std::cin >> numbers[i];
    }

    // Sort the numbers in increasing order
    std::sort(numbers.begin(), numbers.end());

    // Print the sorted numbers
    std::cout << "Sorted list: ";
    for (int i = 0; i < n; ++i) {
        std::cout << numbers[i] << " ";
    }
    std::cout << std::endl;

    return 0;
}